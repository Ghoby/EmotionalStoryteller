﻿using ReGoap.Unity.FSM;

namespace ReGoap.Unity.FSMExample.FSM
{
    public class SmsIdle : SmState
    {
    }
}
