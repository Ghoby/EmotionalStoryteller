﻿namespace ReGoap.Unity.FSMExample.Agents
{
    public class BuilderAgent : ReGoapAgentAdvanced<string, object>
    {
    }
}
