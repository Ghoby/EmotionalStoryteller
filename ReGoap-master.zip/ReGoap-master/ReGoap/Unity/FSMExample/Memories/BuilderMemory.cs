﻿namespace ReGoap.Unity.FSMExample.Memories
{
    public class BuilderMemory : ReGoapMemoryAdvanced<string, object>
    {
    }
}
 

